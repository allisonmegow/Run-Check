I run many programs for my research, many times they take hours. 
I made this short cut and automator workflow to run while I am doing other things. 
It will send a text to a phone number every 30m.
Obviously, adjust the shortcut and automation as needed. :)

INSTRUCTIONS
1. Open shortcut and add runchecker1.shortcut to your shortcuts. Edit to needs.
2. Open runchecker copy.workflow in automator app.Edit to needs.
3. Press play and let 'er rip!

This was made by Allison Megow, 2025
questions can go to allisonmegow@gmail.com
